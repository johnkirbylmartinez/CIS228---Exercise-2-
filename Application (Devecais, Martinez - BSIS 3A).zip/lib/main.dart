import 'package:flutter/material.dart';
import 'package:flutterapp/carefreeapp/generatedloginpagewidget/GeneratedLoginpageWidget.dart';
import 'package:flutterapp/carefreeapp/generatedsignuppagewidget/GeneratedSignupPageWidget.dart';
import 'package:flutterapp/carefreeapp/generateduserprofilewidget/GeneratedUserProfileWidget.dart';
import 'package:flutterapp/carefreeapp/generatedandroid2widget/GeneratedAndroid2Widget.dart';

void main() {
  runApp(CarefreeApp());
}

class CarefreeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedLoginpageWidget',
      routes: {
        '/GeneratedLoginpageWidget': (context) => GeneratedLoginpageWidget(),
        '/GeneratedSignupPageWidget': (context) => GeneratedSignupPageWidget(),
        '/GeneratedUserProfileWidget': (context) =>
            GeneratedUserProfileWidget(),
        '/GeneratedAndroid2Widget': (context) => GeneratedAndroid2Widget(),
      },
    );
  }
}
